import java.util.ArrayList;
import javafx.util.Pair;
import java.util.LinkedList;
import java.util.ArrayList;
import javafx.util.Pair;
import java.util.LinkedList;
import java.util.ArrayList;
import javafx.util.Pair;
import java.util.LinkedList;
import java.util.ArrayList;
import javafx.util.Pair;
import java.util.LinkedList;
import java.util.ArrayList;
import javafx.util.Pair;
import java.util.LinkedList;
import java.util.ArrayList;
import javafx.util.Pair;
import java.util.LinkedList;
import java.util.ArrayList;
import javafx.util.Pair;
import java.util.LinkedList;
import java.util.ArrayList;
import javafx.util.Pair;
import java.util.LinkedList;

/**
 * Implementacion de un grafo dirigido usando listas de adyacencia
 *
 * @author Mauricio Toro, Mateo Agudelo, <su nombre>
 */
public class DigraphAL extends Digraph {
    ArrayList<LinkedList<Pair<Integer,Integer>>> lista;
    public DigraphAL(int size){
        super(size);
        lista = new ArrayList<LinkedList<Pair<Integer,Integer>>>();
        for(int i = 0; i < size; ++i){
            lista.add(new LinkedList<Pair<Integer, Integer>>());
        }
    }
   
    public void addArc(int source, int destination, int weight){
        lista.get(source).add(new Pair(destination, weight)); 
    }
   
    public int getWeight(int source, int destination){
        for(Pair<Integer,Integer> pareja : lista.get(source)){
            if(pareja.getKey() == destination){
                return pareja.getValue();
            }
        }
        return 0;
    }
  
    public ArrayList<Integer> getSuccessors(int vertice){
        ArrayList<Integer> vecinos = new ArrayList<Integer>();
        for(Pair<Integer,Integer> pareja : lista.get(vertice)){
            vecinos.add(pareja.getKey());
        }
        return vecinos;
    }
    
    public static void dibujarGrafo(Digraph g)
     {
        System.out.println("digraph Grafo {");
        System.out.println("node [color=cyan, style=filled];");
        int nv = g.size();
        for (int i = 0; i < nv; i++)
        {
           ArrayList<Integer> lista = g.getSuccessors(i);
           for (int j = 0; j < lista.size(); j++)
             System.out.println("\"" + i + "\" -> \"" + lista.get(j) + "\" [ label=\""+ g.getWeight(i,lista.get(j)) +"\"];");
        }
        System.out.println("}");
     }
     
     public static void main(String[] args){  
     DigraphAL dgal = new DigraphAL(5);
     dgal.addArc(0,1,10);
     dgal.addArc(0,2,3);
     dgal.addArc(1,2,1);
     dgal.addArc(1,3,2);
     dgal.addArc(2,1,4);
     dgal.addArc(2,3,8);
     dgal.addArc(2,4,2);
     dgal.addArc(3,4,7);
     dgal.addArc(4,3,9);
     
     dibujarGrafo(dgal);
    }
}

